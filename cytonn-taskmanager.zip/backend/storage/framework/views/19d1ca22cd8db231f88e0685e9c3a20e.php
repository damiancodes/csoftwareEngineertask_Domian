<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
</head>
<body>
    <div id="app">
        <h1>Welcome to Laravel</h1>
        <p>Your application is running successfully!</p>
    </div>
</body>
</html> <?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>